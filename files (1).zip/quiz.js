// ======== QUIZ DATA (EASY TO CUSTOMIZE) ========
const quizData = [
  {
    question: "What is the capital of France?",
    answers: [
      { text: "Berlin", correct: false },
      { text: "Paris", correct: true },
      { text: "Rome", correct: false },
      { text: "Madrid", correct: false }
    ]
  },
  {
    question: "Which language is used for web apps?",
    answers: [
      { text: "Python", correct: false },
      { text: "JavaScript", correct: true },
      { text: "C++", correct: false },
      { text: "Java", correct: false }
    ]
  },
  {
    question: "Who painted the Mona Lisa?",
    answers: [
      { text: "Vincent Van Gogh", correct: false },
      { text: "Leonardo da Vinci", correct: true },
      { text: "Michelangelo", correct: false },
      { text: "Pablo Picasso", correct: false }
    ]
  },
  {
    question: "What is the boiling point of water?",
    answers: [
      { text: "100°C", correct: true },
      { text: "90°C", correct: false },
      { text: "80°C", correct: false },
      { text: "120°C", correct: false }
    ]
  }
];

// ======== MASCOT DIALOGUES (EASY TO CUSTOMIZE) ========
const mascotDialogues = {
  welcome: "Welcome! I'm Quix, your quiz companion. Ready to test your skills?",
  correct: [
    "Awesome! You got it right! 😎",
    "That's the spirit! 🎉",
    "Quix is proud of you! 🦸"
  ],
  incorrect: [
    "Oops, that's not it. Try the next one! 😅",
    "Almost! Keep going! 💪",
    "Don't worry, Quix believes in you! 🌟"
  ],
  complete: [
    "Quiz complete! Let's see your score...",
    "You finished! Quix is impressed! 🏆"
  ],
  restart: "Ready for another round? Let's go!"
};

// ======== DOM ELEMENTS ========
const quizStart = document.getElementById('quizStart');
const quizForm = document.getElementById('quizForm');
const quizProgress = document.getElementById('quizProgress');
const questionArea = document.getElementById('questionArea');
const answersArea = document.getElementById('answersArea');
const quizResult = document.getElementById('quizResult');
const resultScore = document.getElementById('resultScore');
const resultMessage = document.getElementById('resultMessage');
const restartBtn = document.getElementById('restartBtn');
const startBtn = document.getElementById('startBtn');
const mascotDialogue = document.getElementById('mascotDialogue');
const mascotText = document.getElementById('mascotText');
const quizFeedback = document.getElementById('quizFeedback');
const feedbackForm = document.getElementById('feedbackForm');
const feedbackInput = document.getElementById('feedbackInput');

// ======== STATE ========
let currentQuestion = 0;
let score = 0;
let quizActive = false;

// ======== UTILS ========
function shuffle(arr) {
  // Fisher-Yates shuffle
  let a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function setMascotDialogue(text, animate = true) {
  mascotText.textContent = text;
  if (animate) {
    mascotDialogue.style.animation = 'none';
    // Re-trigger animation
    void mascotDialogue.offsetWidth;
    mascotDialogue.style.animation = '';
  }
}

// ======== QUIZ LOGIC ========
function startQuiz() {
  quizActive = true;
  currentQuestion = 0;
  score = 0;
  quizStart.style.display = 'none';
  quizResult.style.display = 'none';
  quizForm.style.display = 'block';
  quizFeedback.textContent = '';
  setMascotDialogue(mascotDialogues.welcome);
  showQuestion();
}

function showQuestion() {
  const questionObj = quizData[currentQuestion];
  quizProgress.textContent = `Question ${currentQuestion + 1} of ${quizData.length}`;
  questionArea.textContent = questionObj.question;
  answersArea.innerHTML = '';
  let shuffled = shuffle(questionObj.answers);
  shuffled.forEach((answer, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'answer-btn';
    btn.textContent = answer.text;
    btn.setAttribute('data-correct', answer.correct);
    btn.setAttribute('tabindex', 0);
    btn.setAttribute('aria-pressed', 'false');
    btn.setAttribute('aria-label', answer.text + (answer.correct ? ", correct answer" : ""));
    btn.addEventListener('click', () => handleAnswer(btn, answer.correct));
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        btn.click();
      }
    });
    answersArea.appendChild(btn);
  });
  // Focus first answer for accessibility
  setTimeout(() => {
    const firstBtn = answersArea.querySelector('.answer-btn');
    if (firstBtn) firstBtn.focus();
  }, 200);
}

function handleAnswer(btn, isCorrect) {
  if (!quizActive) return;
  Array.from(answersArea.children).forEach(b => {
    b.disabled = true;
    b.setAttribute('aria-pressed', 'false');
  });
  btn.setAttribute('aria-pressed', 'true');
  btn.classList.add(isCorrect ? 'correct' : 'incorrect');
  if (isCorrect) {
    score++;
    quizFeedback.textContent = "Correct!";
    setMascotDialogue(randomFrom(mascotDialogues.correct));
  } else {
    quizFeedback.textContent = "Incorrect!";
    setMascotDialogue(randomFrom(mascotDialogues.incorrect));
  }
  setTimeout(() => {
    quizFeedback.textContent = '';
    nextQuestion();
  }, 1000);
}

function nextQuestion() {
  currentQuestion++;
  if (currentQuestion < quizData.length) {
    showQuestion();
  } else {
    endQuiz();
  }
}

function endQuiz() {
  quizActive = false;
  quizForm.style.display = 'none';
  quizResult.style.display = 'block';
  const pct = Math.round((score / quizData.length) * 100);
  resultScore.textContent = `${score} / ${quizData.length} (${pct}%)`;
  let message = '';
  if (pct === 100) {
    message = "Flawless! Quix bows to your knowledge! 🥇";
  } else if (pct >= 75) {
    message = "Great job! Quix is impressed! Keep it up!";
  } else if (pct >= 50) {
    message = "Not bad! Practice makes perfect!";
  } else {
    message = "Give it another try! Quix is here to help!";
  }
  resultMessage.textContent = message;
  setMascotDialogue(randomFrom(mascotDialogues.complete));
  setTimeout(() => {
    quizResult.focus();
  }, 200);
}

function randomFrom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ======== EVENT LISTENERS ========
startBtn.addEventListener('click', startQuiz);
restartBtn.addEventListener('click', startQuiz);

feedbackForm.addEventListener('submit', function(e) {
  e.preventDefault();
  if (feedbackInput.value.trim().length === 0) return;
  setMascotDialogue("Thank you for your feedback! 💌", true);
  feedbackInput.value = '';
});

// ======== INIT ========
setMascotDialogue(mascotDialogues.welcome);
quizStart.style.display = 'block';
quizForm.style.display = 'none';
quizResult.style.display = 'none';

// ======== ACCESSIBILITY ENHANCEMENTS ========
document.body.addEventListener('keydown', function(e) {
  // Enable left/right to switch answers, Enter to select
  if (!quizActive) return;
  if (['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
    const buttons = Array.from(answersArea.querySelectorAll('.answer-btn'));
    let idx = buttons.findIndex(b => document.activeElement === b);
    if (idx === -1) idx = 0;
    let nextIdx = idx;
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') nextIdx = (idx + 1) % buttons.length;
    if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') nextIdx = (idx - 1 + buttons.length) % buttons.length;
    buttons[nextIdx].focus();
    e.preventDefault();
  }
});